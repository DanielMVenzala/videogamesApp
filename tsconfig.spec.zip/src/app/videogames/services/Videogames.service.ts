import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RESTVideogames } from '../interfaces/videogamesResponse';
import { VideogamesMapper } from '../mapper/videogames.mapper';

@Injectable({providedIn: 'root'})
export class VideogamesService {
  constructor(private http: HttpClient) { }


  private api = 'http://localhost:3000/videogames';

  getAllVideogames(): Observable<RESTVideogames[]> {
  return this.http.get<RESTVideogames[]>(this.api);
}



}
