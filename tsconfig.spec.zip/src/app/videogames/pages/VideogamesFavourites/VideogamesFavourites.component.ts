import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'app-videogames-favourites',
  imports: [],
  templateUrl: './VideogamesFavourites.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VideogamesFavouritesComponent { }
