import { ChangeDetectionStrategy, Component, inject, OnInit } from '@angular/core';
import { RESTVideogames } from '../../interfaces/videogamesResponse';
import { VideogamesService } from '../../services/Videogames.service';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-videogames-list',
  imports: [CommonModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './VideogamesList.component.html',
})
export class VideogamesListComponent implements OnInit {
  videogames: RESTVideogames[] = [];

  constructor(private videogamesService: VideogamesService) {}

  // ngOnInit(): void {
  //   this.videogamesService.getAllVideogames().subscribe({
  //     next: (data) => {
  //       this.videogames = data;
  //     },
  //     error: (err) => {
  //       console.error('Error fetching videogames:', err);
  //     }
  //   });
  // }

  ngOnInit(): void {
  this.videogamesService.getAllVideogames().subscribe({
    next: (data) => this.videogames = data,
    error: (err) => console.error('Error fetching videogames:', err)
  });
}


 }
