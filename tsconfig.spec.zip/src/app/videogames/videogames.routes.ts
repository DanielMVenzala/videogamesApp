import { Routes } from '@angular/router';
import { VideogamesLayoutComponent } from './layout/VideogamesLayout/VideogamesLayout.component';
import { VideogamesListComponent } from './pages/VideogamesList/VideogamesList.component';
import { VideogamesFavouritesComponent } from './pages/VideogamesFavourites/VideogamesFavourites.component';

export const videoGamesRoutes: Routes = [
  {
    path:'',
    component: VideogamesLayoutComponent,

    children: [
      {
        path: 'list',
        component: VideogamesListComponent
      },

      {
        path: 'favourites',
        component: VideogamesFavouritesComponent
      },




      {
        path: '**',
        redirectTo: 'list'
      }

    ]
  },



];

export default videoGamesRoutes;
