import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'top-menu',
  imports: [],
  templateUrl: './top-menu.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TopMenuComponent { }
